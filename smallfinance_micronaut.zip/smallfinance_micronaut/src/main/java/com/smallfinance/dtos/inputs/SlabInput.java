package com.smallfinance.dtos.inputs;

import lombok.Data;

@Data
public class SlabInput {
    private String tenures;

    private String interestRate;

    private String typeOfTransaction;
}
