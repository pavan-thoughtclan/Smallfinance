package com.smallfinance.enums;

public enum AccountType {
    Savings
}
