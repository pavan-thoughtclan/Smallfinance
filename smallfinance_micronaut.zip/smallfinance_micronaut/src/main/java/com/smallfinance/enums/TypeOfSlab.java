package com.smallfinance.enums;

public enum TypeOfSlab {
    WITHDRAWAL,DEPOSIT,TRANSFER,FD,GOLD_LOAN,PERSONAL_LOAN,HOME_LOAN,EDUCATION_LOAN,RD
}
