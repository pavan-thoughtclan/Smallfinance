package com.smallfinance.enums;

public enum TypeOfLoans {
    GOLD_LOAN,HOME_LOAN,EDUCATION_LOAN,PERSONAL_LOAN

}
