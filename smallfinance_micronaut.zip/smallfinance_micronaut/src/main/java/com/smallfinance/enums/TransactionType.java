package com.smallfinance.enums;

public enum TransactionType {
    DEBITED,CREDITED

}
