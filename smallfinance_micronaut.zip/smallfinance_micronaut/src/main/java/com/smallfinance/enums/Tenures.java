package com.smallfinance.enums;

public enum Tenures {
    ONE_MONTH, THREE_MONTHS, SIX_MONTHS, ONE_YEAR
}
