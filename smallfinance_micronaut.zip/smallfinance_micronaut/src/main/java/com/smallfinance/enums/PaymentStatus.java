package com.smallfinance.enums;

public enum PaymentStatus {
    PAID,UNPAID,UPCOMING
}
