package com.smallfinance.enums;

public enum RdStatus {
    ACTIVE, MATURED, CLOSED

}
