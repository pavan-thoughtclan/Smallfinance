package com.smallfinance.enums;

public enum Status {
    UNDER_REVIEW, APPROVED, REJECTED
}
